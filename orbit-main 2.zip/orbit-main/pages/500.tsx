import { motion } from 'framer-motion';
import Head from 'next/head';
import Link from 'next/link';
import Router from 'next/router';

export default function Error() {
  return (
    <>
      <Head>
        <title>500 — Internal Server Error</title>
        <meta
          name='robots'
          content='noindex'
        />
      </Head>

      <div className='flex min-h-screen items-center justify-center bg-gradient-to-b from-zinc-900 via-zinc-950 to-zinc-900 px-6'>
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
          className='max-w-4xl w-full bg-zinc-900/60 backdrop-blur-md rounded-2xl p-8 sm:p-12 text-center shadow-2xl border border-zinc-800'
        >
          <div className='flex flex-col sm:flex-row items-center gap-8'>
            <div className='flex-shrink-0'>
              <motion.div
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5 }}
                className='text-7xl font-extrabold text-[#ff0099]'
                aria-hidden
              >
                500
              </motion.div>
            </div>

            <div className='text-left flex-1'>
              <h1 className='text-2xl sm:text-3xl font-semibold text-zinc-200'>
                Internal server error
              </h1>
              <p className='mt-3 text-zinc-400 max-w-xl'>
                Sorry — something went wrong on our end. The team has been notified, but you can try
                the options below to continue.
              </p>

              <div className='mt-6 flex flex-col sm:flex-row sm:items-center sm:gap-4 gap-3'>
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => Router.push('/')}
                  className='inline-flex items-center justify-center px-5 py-2 rounded-lg bg-[#ff0099] text-white font-medium shadow-sm hover:brightness-105 transition'
                  aria-label='Return to home'
                >
                  Return to home
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => location.reload()}
                  className='inline-flex items-center justify-center px-4 py-2 rounded-lg bg-zinc-800 text-zinc-200 border border-zinc-700 hover:bg-zinc-800/90 transition'
                  aria-label='Retry'
                >
                  Retry
                </motion.button>

                <Link
                  href='https://github.com/PlanetaryOrbit/orbit/issues'
                  target='_blank'
                  rel='noopener noreferrer'
                  className='inline-flex items-center justify-center px-4 py-2 rounded-lg text-zinc-300 hover:text-white border border-zinc-700'
                >
                  Report an issue
                </Link>
              </div>

              <p className='mt-4 text-sm text-zinc-500'>
                If this keeps happening, contact the workspace admin or try again later.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
}
