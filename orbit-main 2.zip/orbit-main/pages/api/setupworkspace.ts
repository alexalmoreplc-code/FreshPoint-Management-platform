import { User } from '@/types/index.d';
import { fetchAvatar } from '@/utils/avatar';
import prisma from '@/utils/database';
import { setRegistry } from '@/utils/registryManager';
import { isGroupAllied } from '@/utils/roblox';
import { createSession } from '@/utils/session';
import { getUsername, getDisplayName } from '@/utils/userinfoEngine';
import bcryptjs from 'bcryptjs';
import type { NextApiRequest, NextApiResponse } from 'next';
import * as noblox from 'noblox.js';

type Data = {
  success: boolean;
  error?: string;
  user?: User & { isOwner: boolean };
  debug?: any;
};

export default async function handler(req: NextApiRequest, res: NextApiResponse<Data>) {
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      error: 'Method not allowed',
    });
  }

  if (!req.body || typeof req.body !== 'object') {
    return res.status(400).json({
      success: false,
      error: 'Invalid request body - must be JSON',
    });
  }

  const { groupid, username, password, color, opencloudKey } = req.body;

  if (!groupid || !username || !password || !color) {
    return res.status(400).json({
      success: false,
      error: 'Missing required fields',
    });
  }

  const groupIdNumber = typeof groupid === 'string' ? Number(groupid) : groupid;

  if (!Number.isInteger(groupIdNumber)) {
    return res.status(400).json({
      success: false,
      error: 'Invalid groupid',
    });
  }

  try {
    const trimmedUsername = username.trim();

    let userid: number;

    try {
      const robloxResponse = await fetch('https://users.roblox.com/v1/usernames/users', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          usernames: [trimmedUsername],
          excludeBannedUsers: false,
        }),
      });

      const responseText = await robloxResponse.text();

      if (!robloxResponse.ok) {
        console.error('[Roblox] Username lookup failed:', {
          username: trimmedUsername,
          status: robloxResponse.status,
          statusText: robloxResponse.statusText,
          body: responseText,
        });

        if (robloxResponse.status === 400) {
          return res.status(400).json({
            success: false,
            error: 'Roblox rejected the username lookup. Please check the username and try again.',
          });
        }

        return res.status(502).json({
          success: false,
          error: `Roblox could not be reached or returned an error (HTTP ${robloxResponse.status}). Please try again in a moment.`,
        });
      }

      let data: {
        data?: Array<{
          requestedUsername: string;
          hasVerifiedBadge: boolean;
          id: number;
          name: string;
          displayName: string;
        }>;
      };

      try {
        data = JSON.parse(responseText);
      } catch {
        console.error('[Roblox] Invalid JSON response:', responseText);
        return res.status(502).json({
          success: false,
          error: 'Roblox returned an invalid response. Please try again in a moment.',
        });
      }
      const robloxUser = data.data?.[0];
      if (!robloxUser) {
        return res.status(404).json({
          success: false,
          error: `Roblox username "${trimmedUsername}" was not found. Please check that you entered your username correctly.`,
        });
      }
      userid = robloxUser.id;
    } catch (error) {
      console.error('[Roblox] Username lookup request failed:', {
        username: trimmedUsername,
        error,
      });
      return res.status(502).json({
        success: false,
        error: "We couldn't contact Roblox to verify your username. Please try again in a moment.",
      });
    }

    const existingWorkspace = await prisma.workspace.findUnique({
      where: {
        groupId: groupIdNumber,
      },
    });

    if (existingWorkspace) {
      return res.status(403).json({
        success: false,
        error: 'Workspace already exists',
      });
    }

    const [logo, group, verified] = await Promise.all([
      noblox.getLogo(groupIdNumber, '420x420').catch(() => ''),

      noblox.getGroup(groupIdNumber).catch(() => null),

      isGroupAllied(groupIdNumber).catch(() => false),
    ]);

    const groupName = group?.name ?? `Group ${groupIdNumber}`;

    const groupLogo = logo ?? '';

    const hashedPassword = await bcryptjs.hash(password, 10);

    const existingUserCount = await prisma.user.count();

    if (existingUserCount > 0) {
      return res.status(403).json({
        success: false,
        error: 'Instance setup has already been completed',
      });
    }

    await prisma.$transaction(async (tx) => {
      await tx.workspace.create({
        data: {
          groupId: groupIdNumber,
          groupName,
          groupLogo,
          lastSynced: new Date(),
          isVerified: verified,
          lastSyncedSuccessful: null,
        },
      });

      await tx.config.createMany({
        data: [
          {
            key: 'customization',
            workspaceGroupId: groupIdNumber,
            value: { color },
          },
          {
            key: 'theme',
            workspaceGroupId: groupIdNumber,
            value: color,
          },
          {
            key: 'guides',
            workspaceGroupId: groupIdNumber,
            value: { enabled: true },
          },
          {
            key: 'sessions',
            workspaceGroupId: groupIdNumber,
            value: { enabled: true },
          },
          {
            key: 'allies',
            workspaceGroupId: groupIdNumber,
            value: { enabled: true },
          },
          {
            key: 'leaderboard',
            workspaceGroupId: groupIdNumber,
            value: { enabled: true },
          },
          {
            key: 'notices',
            workspaceGroupId: groupIdNumber,
            value: { enabled: true },
          },
          {
            key: 'resignations',
            workspaceGroupId: groupIdNumber,
            value: { enabled: false },
          },
          {
            key: 'policies',
            workspaceGroupId: groupIdNumber,
            value: { enabled: false },
          },
          {
            key: 'home',
            workspaceGroupId: groupIdNumber,
            value: { widgets: [] },
          },
        ],
      });

      const user = await tx.user.create({
        data: {
          userid: BigInt(userid),
          info: {
            create: {
              passwordhash: hashedPassword,
            },
          },
          isOwner: true,
        },
      });

      const defaultRole = await tx.role.create({
        data: {
          name: 'Default',
          workspaceGroupId: groupIdNumber,
          permissions: [],
          groupRoles: [],
        },
      });

      await tx.user.update({
        where: {
          userid: BigInt(userid),
        },
        data: {
          roles: {
            connect: {
              id: defaultRole.id,
            },
          },
        },
      });

      await tx.workspaceMember.create({
        data: {
          workspaceGroupId: groupIdNumber,
          userId: BigInt(userid),
          joinDate: new Date(),
          isAdmin: true,
        },
      });

      if (typeof opencloudKey === 'string' && opencloudKey.trim().length > 0) {
        await tx.config.create({
          data: {
            key: 'roblox_opencloud',
            workspaceGroupId: groupIdNumber,
            value: {
              enabled: true,
              key: opencloudKey.trim(),
            },
          },
        });
      }
    });
    const session = await createSession(
      BigInt(userid),
      (req.headers['x-forwarded-for'] as string) ?? req.socket.remoteAddress,
      req.headers['user-agent'],
    );

    res.setHeader('Set-Cookie', [
      `session_token=${session.token}; Path=/; HttpOnly; SameSite=lax; Max-Age=${
        60 * 60 * 24 * 30
      }`,
      `app_setup=true; Path=/; HttpOnly; SameSite=lax`,
    ]);

    await setRegistry(req.headers.host as string);

    const userInfo: User & { isOwner: boolean } = {
      userId: userid,
      username: await getUsername(userid),
      displayname: await getDisplayName(userid),
      thumbnail: await fetchAvatar(userid, {
        type: 'headshot',
        size: '180x180',
      }),
      isOwner: true,
    };

    return res.status(200).json({
      success: true,
      user: userInfo,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: 'Internal server error',
      debug: process.env.NODE_ENV === 'development' ? error : undefined,
    });
  }
}
