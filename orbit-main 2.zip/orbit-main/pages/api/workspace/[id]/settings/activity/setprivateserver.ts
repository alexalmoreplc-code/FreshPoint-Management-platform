import { getConfig, setConfig } from '@/utils/configEngine';
import prisma from '@/utils/database';
import { logAudit } from '@/utils/logs';
import { withPermissionCheck } from '@/utils/permissionsManager';
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  success: boolean;
  enabled?: boolean;
  error?: string;
};

export default withPermissionCheck(handler, 'admin');

export async function handler(req: NextApiRequest, res: NextApiResponse<Data>) {
  if (req.method !== 'POST')
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  const workspace = await prisma.workspace.findFirst({
    where: {
      groupId: parseInt(req.query.id as string),
    },
  });
  if (!workspace) return res.status(404).json({ success: false, error: 'Workspace not found' });

  const activityconfig = await getConfig('activity', parseInt(req.query.id as string));
  const newconfig = {
    ...activityconfig,
    privateServerEnabled: Boolean(req.body.enabled),
  };
  await setConfig('activity', newconfig, parseInt(req.query.id as string));

  try {
    await logAudit(
      parseInt(req.query.id as string),
      (req as any).auth?.userId || null,
      'settings.activity.privateserver.update',
      'activity.privateserver',
      { before: activityconfig, after: newconfig },
    );
  } catch (e) {}

  res.status(200).send({
    success: true,
    enabled: req.body.enabled,
  });
}
