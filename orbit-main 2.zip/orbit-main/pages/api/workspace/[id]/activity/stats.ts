import { AuthenticatedRequest } from '@/lib/withAuth';
import { getConfig } from '@/utils/configEngine';
import prisma from '@/utils/database';
import { withPermissionCheck } from '@/utils/permissionsManager';
// import { withAuth } from '@/lib/withSession'
import { getUsername, getThumbnail, getDisplayName } from '@/utils/userinfoEngine';
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next';

type Data = {
  success: boolean;
  message?: object;
  error?: string;
};

export default withPermissionCheck(handler);

export async function handler(req: AuthenticatedRequest, res: NextApiResponse<Data>) {
  if (req.method !== 'GET')
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  if (!req.auth.userId) return res.status(401).json({ success: false, error: 'Not logged in' });

  const workspaceId = parseInt(req.query.id as string);
  const activityConfig = await getConfig('activity', workspaceId);
  const idleTimeEnabled = activityConfig?.idleTimeEnabled ?? true;

  const sessions = await prisma.activitySession.findMany({
    where: {
      workspaceGroupId: workspaceId,
      active: false,
      archived: { not: true },
    },
  });

  const messageArr: number[] = [];
  const idleArr: number[] = [];

  for (const session of sessions) {
    messageArr.push(session.messages as number);
    if (idleTimeEnabled && session.idleTime) idleArr.push(Number(session.idleTime));
  }

  return res.status(200).json({
    success: true,
    message: {
      messages: messageArr.length
        ? messageArr.reduce((total, currentValue) => total + currentValue, 0)
        : 0,
      idle: idleArr.length ? idleArr.reduce((total, currentValue) => total + currentValue, 0) : 0,
      idleTimeEnabled,
    },
  });
}
