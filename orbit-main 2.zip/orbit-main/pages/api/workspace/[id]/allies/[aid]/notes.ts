import { AuthenticatedRequest, withAuth } from '@/lib/withAuth';
import prisma from '@/utils/database';
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiResponse } from 'next';

type Data = {
  success: boolean;
  error?: string;
  ally?: any;
};

const withAllyPermissionCheck = (handler: any) => {
  return withAuth(async (req: AuthenticatedRequest, res: NextApiResponse) => {
    const uid = req.auth.userId;
    if (!uid) return res.status(401).json({ success: false, error: 'Unauthorized' });
    if (!req.query.id)
      return res.status(400).json({ success: false, error: 'Missing required fields' });
    if (!req.query.aid) return res.status(400).json({ success: false, error: 'Missing ally ID' });

    const workspaceId = parseInt(req.query.id as string);
    const allyId = req.query.aid as string;

    const user = await prisma.user.findFirst({
      where: {
        userid: BigInt(uid),
      },
      include: {
        roles: {
          where: {
            workspaceGroupId: workspaceId,
          },
        },
        workspaceMemberships: {
          where: {
            workspaceGroupId: workspaceId,
          },
        },
      },
    });

    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const membership = user.workspaceMemberships[0];
    const isAdmin = membership?.isAdmin || false;
    const userrole = user.roles[0];
    if (!userrole) return res.status(401).json({ success: false, error: 'Unauthorized' });

    // Check if user has management permissions
    if (isAdmin) return handler(req, res);
    if (
      userrole.permissions?.includes('add_alliance_notes') ||
      userrole.permissions?.includes('edit_alliance_notes')
    )
      return handler(req, res);

    // Check if user is a representative of this specific ally
    const ally = await prisma.ally.findFirst({
      where: {
        id: allyId,
        workspaceGroupId: workspaceId,
        reps: {
          some: {
            userid: BigInt(uid),
          },
        },
      },
    });

    if (ally) return handler(req, res);

    return res.status(401).json({ success: false, error: 'Unauthorized' });
  });
};

export default withAllyPermissionCheck(handler);

export async function handler(req: AuthenticatedRequest, res: NextApiResponse<Data>) {
  if (req.method !== 'PATCH')
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  if (!req.auth.userId) return res.status(401).json({ success: false, error: 'Not logged in' });
  if (!req.query.aid) return res.status(400).json({ success: false, error: 'Missing ally id' });
  if (typeof req.query.aid !== 'string')
    return res.status(400).json({ success: false, error: 'Invalid ally id' });
  const { notes } = req.body;
  if (!notes) return res.status(400).json({ success: false, error: 'Missing content' });

  try {
    const ally: any = await prisma.ally.updateMany({
      where: {
        id: String(req.query.aid),
        workspaceGroupId: parseInt(req.query.id as string),
      },
      data: {
        notes: notes,
      },
    });

    return res.status(200).json({ success: true, ally: ally });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, error: 'Something went wrong' });
  }
}
