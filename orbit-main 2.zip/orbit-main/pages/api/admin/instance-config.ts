import { AuthenticatedRequest, withAuth } from '@/lib/withAuth';
import prisma from '@/utils/database';
import type { NextApiRequest, NextApiResponse } from 'next';

export default withAuth(handler);

export async function handler(req: AuthenticatedRequest, res: NextApiResponse) {
  if (!req.auth.userId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const user = await prisma.user.findUnique({
    where: { userid: BigInt(req.auth.userId) },
    select: { isOwner: true },
  });

  if (!user?.isOwner) {
    return res.status(403).json({ error: 'Access denied. Owner privileges required.' });
  }

  if (req.method === 'GET') {
    try {
      const envClientId = process.env.ROBLOX_CLIENT_ID;
      const envClientSecret = process.env.ROBLOX_CLIENT_SECRET;
      const envOAuthOnly = process.env.ROBLOX_OAUTH_ONLY === 'true';
      const envRedirectUri =
        process.env.NEXTAUTH_URL || process.env.PUBLIC_URL
          ? `${process.env.NEXTAUTH_URL || process.env.PUBLIC_URL}/api/auth/roblox/callback`
          : '';
      const envWorkspaceRedirect = process.env.ROBLOX_WORKSPACE_REDIRECTID ? true : false;
      const envWorkspaceID = process.env.ROBLOX_WORKSPACE_REDIRECTID;
      const envDiscordAppID = process.env.DISCORD_APPLICATION_ID;
      const envDCClientSecret = process.env.DISCORD_SECRET;
      const envGoogleClientID = process.env.GOOGLE_APP_ID;
      const envGoogleClientSecret = process.env.GOOGLE_SECRET;
      const envGoogleEmailFiltration = process.env.GOOGLE_EMAIL_FILTRATION;
      const usingEnvVars = !!(
        (envClientId && envClientSecret) ||
        envWorkspaceID ||
        (envDiscordAppID && envDCClientSecret) ||
        (envGoogleClientID && envGoogleClientSecret) ||
        envGoogleEmailFiltration
      );

      if (usingEnvVars) {
        const [bgConfig, tintEnabledConfig, tintOpacityConfig] = await Promise.all([
          prisma.instanceConfig.findUnique({
            where: { key: 'loginBackground' },
          }),
          prisma.instanceConfig.findUnique({
            where: { key: 'loginBackgroundTintEnabled' },
          }),
          prisma.instanceConfig.findUnique({
            where: { key: 'loginBackgroundTintOpacity' },
          }),
        ]);
        return res.json({
          robloxClientId: '••••••••',
          robloxClientSecret: '••••••••',
          discordApplicationID: envDiscordAppID ? '••••••••' : '',
          discordClientSecret: envDCClientSecret ? '••••••••' : '',
          oauthOnlyLogin: envOAuthOnly,
          redirectWorkspace: envWorkspaceRedirect,
          redirectWID: envWorkspaceID,
          google_id: envGoogleClientID ? '••••••••' : '',
          google_secret: envGoogleClientID ? '••••••••' : '',
          google_email_filtration: envGoogleEmailFiltration || null,
          redirectUri: envRedirectUri,
          loginBackground: typeof bgConfig?.value === 'string' ? bgConfig.value : null,
          loginBackgroundTintEnabled:
            typeof tintEnabledConfig?.value === 'boolean' ? tintEnabledConfig.value : true,
          loginBackgroundTintOpacity:
            typeof tintOpacityConfig?.value === 'number' ? tintOpacityConfig.value : 60,
          usingEnvVars: true,
        });
      }

      const configs = await prisma.instanceConfig.findMany({
        where: {
          key: {
            in: [
              'robloxClientId',
              'robloxClientSecret',
              'robloxRedirectUri',
              'oauthOnlyLogin',
              'redirectWorkspace',
              'discordAppID',
              'discordAppSecret',
              'loginBackground',
              'google_id',
              'google_secret',
              'google_email_filtration',
            ],
          },
        },
      });

      const configMap = configs.reduce(
        (acc: any, config: any) => {
          acc[config.key] = config.value;
          return acc;
        },
        {} as Record<string, any>,
      );

      return res.json({
        robloxClientId: configMap.robloxClientId || '',
        robloxClientSecret: configMap.robloxClientSecret || '',
        robloxRedirectUri: configMap.robloxRedirectUri || '',
        oauthOnlyLogin: configMap.oauthOnlyLogin || false,
        discordApplicationID: configMap.discordAppID,
        discordClientSecret: configMap.discordAppSecret,
        usingEnvVars: false,
        redirectWorkspace: configMap.redirectWorkspace || '',
        google_id: configMap.google_id || '',
        google_secret: configMap.google_secret || '',
        google_email_filtration: configMap.google_email_filtration,
        loginBackground:
          typeof configMap.loginBackground === 'string' ? configMap.loginBackground : null,
      });
    } catch (error) {
      console.error('Failed to fetch instance config:', error);
      return res.status(500).json({ error: 'Failed to fetch configuration' });
    }
  }

  if (req.method === 'POST') {
    const envClientId = process.env.ROBLOX_CLIENT_ID;
    const envClientSecret = process.env.ROBLOX_CLIENT_SECRET;
    const envRedirectUri = process.env.ROBLOX_REDIRECT_URI;
    const envWorkspaceID = process.env.ROBLOX_WORKSPACE_REDIRECTID;
    const envDiscordAppID = process.env.DISCORD_APPLICATION_ID;
    const envDCClientSecret = process.env.DISCORD_SECRET;
    const envGoogleClientID = process.env.GOOGLE_APP_ID;
    const envGoogleClientSecret = process.env.GOOGLE_SECRET;
    const envGoogleEmailFiltration = process.env.GOOGLE_EMAIL_FILTRATION;
    const usingEnvVars = !!(
      (envClientId && envClientSecret) ||
      envRedirectUri ||
      envWorkspaceID ||
      (envDiscordAppID && envDCClientSecret) ||
      (envGoogleClientID && envGoogleClientSecret) ||
      envGoogleEmailFiltration
    );

    if (usingEnvVars) {
      return res.status(403).json({
        error: 'Cannot modify OAuth configuration when environment variables are set',
        usingEnvVars: true,
      });
    }

    const {
      robloxClientId,
      robloxClientSecret,
      robloxRedirectUri,
      oauthOnlyLogin,
      redirectWorkspaceID,
      discordAppId,
      discordSecret,
      google_id,
      google_secret,
      google_email_filtration,
      loginBackgroundTintEnabled,
      loginBackgroundTintOpacity,
    } = req.body;

    try {
      const updates = [
        {
          key: 'robloxClientId',
          value: typeof robloxClientId === 'string' ? robloxClientId.trim() : robloxClientId || '',
        },
        {
          key: 'robloxClientSecret',
          value:
            typeof robloxClientSecret === 'string'
              ? robloxClientSecret.trim()
              : robloxClientSecret || '',
        },
        {
          key: 'robloxRedirectUri',
          value:
            typeof robloxRedirectUri === 'string'
              ? robloxRedirectUri.trim()
              : robloxRedirectUri || '',
        },
        {
          key: 'discordAppID',
          value: typeof discordAppId === 'string' ? discordAppId.trim() : discordAppId || '',
        },
        {
          key: 'discordAppSecret',
          value: typeof discordSecret === 'string' ? discordSecret.trim() : discordSecret || '',
        },
        { key: 'oauthOnlyLogin', value: oauthOnlyLogin || false },
        {
          key: 'loginBackgroundTintEnabled',
          value:
            typeof loginBackgroundTintEnabled === 'boolean' ? loginBackgroundTintEnabled : true,
        },
        {
          key: 'loginBackgroundTintOpacity',
          value:
            typeof loginBackgroundTintOpacity === 'number'
              ? Math.min(100, Math.max(0, loginBackgroundTintOpacity))
              : 60,
        },
        {
          key: 'google_id',
          value: typeof google_id === 'string' ? google_id.trim() : google_id || '',
        },
        {
          key: 'google_secret',
          value: typeof google_secret === 'string' ? google_secret.trim() : google_id || '',
        },
        {
          key: 'google_email_filtration',
          value:
            typeof google_email_filtration === 'string'
              ? google_email_filtration.trim()
              : google_email_filtration || '',
        },
      ];

      if (redirectWorkspaceID) {
        updates.push({
          key: 'redirectWorkspace',
          value:
            typeof redirectWorkspaceID === 'string' && redirectWorkspaceID.length > 0
              ? redirectWorkspaceID.trim()
              : '',
        });
      }

      await Promise.all(
        updates.map(({ key, value }) =>
          prisma.instanceConfig.upsert({
            where: { key },
            update: { value, updatedAt: new Date() },
            create: { key, value, updatedAt: new Date() },
          }),
        ),
      );
      return res.json({
        success: true,
        message: 'Configuration saved successfully',
      });
    } catch (error) {
      console.error('Failed to save instance config:', error);
      return res.status(500).json({ error: 'Failed to save configuration' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
