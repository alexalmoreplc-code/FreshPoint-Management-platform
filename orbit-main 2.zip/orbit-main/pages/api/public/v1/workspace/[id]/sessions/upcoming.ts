import { withKey } from '@/lib/withAuth';
import prisma from '@/utils/database';
import type { NextApiRequest, NextApiResponse } from 'next';

export default withKey(handler);

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET')
    return res.status(405).json({ success: false, error: 'Method not allowed' });

  const workspaceId = Number.parseInt(req.query.id as string);
  if (!workspaceId) return res.status(400).json({ success: false, error: 'Missing workspace ID' });

  const {
    endDate,
    category,
    startDate,
    status,
    limit,
    page,
    hideClaimed,
    showClaimed,
    hoursAhead,
  } = req.query;

  const DEFAULT_HOURS_AHEAD = 24;
  const MAX_HOURS_AHEAD = 24 * 30;

  const parsedHoursAhead = Number(hoursAhead);
  const windowHours =
    Number.isFinite(parsedHoursAhead) && parsedHoursAhead > 0
      ? Math.min(parsedHoursAhead, MAX_HOURS_AHEAD)
      : DEFAULT_HOURS_AHEAD;

  const start = startDate ? new Date(startDate as string) : new Date();

  const end = endDate
    ? new Date(endDate as string)
    : (() => {
        const future = startDate ? new Date(start) : new Date();
        future.setTime(future.getTime() + windowHours * 60 * 60 * 1000);
        return future;
      })();

  if (isNaN(start.getTime()) || isNaN(end.getTime()))
    return res.status(400).json({ success: false, error: 'Invalid date format' });

  if (start >= end)
    return res.status(400).json({ success: false, error: 'startDate must be before endDate' });

  const take = Math.min(Number(limit) || 50, 10000);
  const skip = (Math.max(Number(page) || 1, 1) - 1) * take;

  if (hideClaimed === 'true' && showClaimed === 'true')
    return res.status(400).json({
      success: false,
      error: 'hideClaimed and showClaimed cannot both be true',
    });

  try {
    const where: any = {
      sessionType: { workspaceGroupId: workspaceId },
      date: { gte: start, lte: end },
    };

    if (category) where.type = category as string;

    if (hideClaimed === 'true') {
      where.users = { none: {} };
    } else if (showClaimed === 'true') {
      where.users = { some: {} };
    }

    if (status) {
      switch (status) {
        case 'scheduled':
          where.ended = false;
          where.startedAt = null;
          where.date = { ...where.date, gte: new Date() };
          break;
        case 'in-progress':
          where.ended = false;
          where.startedAt = { not: null };
          break;
        case 'ended':
          where.ended = true;
          break;
        case 'missed':
          where.ended = false;
          where.startedAt = null;
          where.date = { ...where.date, lte: new Date() };
          break;
        default:
          return res.status(400).json({
            success: false,
            error: `Invalid status filter: ${status}`,
          });
      }
    }

    const [sessions, total] = await Promise.all([
      prisma.session.findMany({
        where,
        include: {
          owner: { select: { userid: true, username: true, picture: true } },
          sessionType: {
            select: {
              id: true,
              name: true,
              description: true,
              gameId: true,
              slots: true,
            },
          },
          users: {
            include: {
              user: { select: { userid: true, username: true, picture: true } },
            },
          },
          notes: true,
        },
        orderBy: { date: 'asc' },
        take,
        skip,
      }),
      prisma.session.count({ where }),
    ]);

    const formattedSessions = sessions.map((session) => ({
      id: session.id,
      name: session.name,
      date: session.date,
      startedAt: session.startedAt,
      ended: session.ended,
      cancelled: session.cancelled,
      cancellationReason: session.cancellationReason,
      type: {
        id: session.sessionType.id,
        name: session.sessionType.name,
        description: session.sessionType.description,
        category: session.type,
        gameId: session.sessionType.gameId ? Number(session.sessionType.gameId) : null,
        slots: session.sessionType.slots,
      },
      host: session.owner
        ? {
            userId: Number(session.owner.userid),
            username: session.owner.username,
            thumbnail: session.owner.picture,
          }
        : null,
      participants: session.users.map((u) => ({
        userId: Number(u.user.userid),
        username: u.user.username,
        thumbnail: u.user.picture,
        slot: u.slot,
        role: u.roleID,
      })),
      status: session.ended
        ? 'ended'
        : session.startedAt
          ? 'in-progress'
          : session.date < new Date()
            ? 'missed'
            : 'scheduled',
      notes: session.notes.map((note) => ({
        id: note.id,
        authorId: note.authorId,
        content: note.content,
        createdAt: note.createdAt,
        updatedAt: note.updatedAt,
      })),
    }));

    const sessionsByDate = formattedSessions.reduce<Record<string, typeof formattedSessions>>(
      (acc, session) => {
        const key = session.date.toISOString().split('T')[0];
        (acc[key] ??= []).push(session);
        return acc;
      },
      {},
    );

    return res.status(200).json({
      success: true,
      sessions: formattedSessions,
      sessionsByDate,
      dateRange: {
        startDate: start.toISOString(),
        endDate: end.toISOString(),
        hoursAhead: !startDate && !endDate ? windowHours : undefined,
      },
      pagination: {
        total,
        page: Math.max(Number(page) || 1, 1),
        pageSize: take,
        totalPages: Math.ceil(total / take),
      },
    });
  } catch (error) {
    console.error('Error fetching sessions:', error);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}
